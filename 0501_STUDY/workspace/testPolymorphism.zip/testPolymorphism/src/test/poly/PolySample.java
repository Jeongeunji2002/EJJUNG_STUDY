package test.poly;

public class PolySample {
	//메소드 오버로딩(overloading) : 취급하는 데이터 종류가 다를 때
	//메소드 매개변수에 다형성 적용
	
	public void printObject(String ref) {
		System.out.println(ref);
	}
	
	public void printObject(java.util.Date ref) {
		System.out.println(ref);
	}

	public void printObject(java.util.GregorianCalendar ref) {
		System.out.println(ref);
	}
	
	public void printObject(Integer ref) {
		System.out.println(ref);
	}
	
	public void printObject(Double ref) {
		System.out.println(ref);
	}
}
