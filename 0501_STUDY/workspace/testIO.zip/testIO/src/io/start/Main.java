package io.start;

import io.view.Menu;

public class Main {

	public static void main(String[] args) {
		Menu.display();
	}
}
