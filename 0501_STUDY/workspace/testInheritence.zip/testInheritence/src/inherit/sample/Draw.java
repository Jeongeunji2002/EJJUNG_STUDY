package inherit.sample;

public interface Draw extends Style, java.io.Serializable {

}
