package inherit.sample;

public interface Style {

}
